import 'package:flutter/material.dart';
import 'package:youtimizer/Pages/Login.dart';
import 'package:youtimizer/Modal/Shared.dart';
import 'package:youtimizer/Widgets/Loader.dart';
import 'package:youtimizer/Modal/Authentication.dart';
import 'package:youtimizer/Widgets/Theme.dart';
import 'package:youtimizer/Modal/HomeData.dart';
import 'package:youtimizer/Modal/CustomError.dart';
import 'package:fcharts/fcharts.dart';
import 'package:youtimizer/Widgets/CustomGraph.dart';
import 'package:youtimizer/Pages/PdfView.dart';
import 'package:youtimizer/Pages/BattingPage.dart';
import 'package:youtimizer/Pages/Address.dart';

final bgColor = const Color(0xff99cc33);

class Home extends StatefulWidget {
  int uid;

  Home({this.uid});

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return HomeState();
  }
}

class HomeState extends State<Home> {
  Shared shared = Shared();
  Authentication authentication = Authentication();
  String address;
  bool inProgress = true;
  HomeData homeData = HomeData();
  GraphData graphData = GraphData(y: [], x: []);
  List<String> x = [];
  List<double> y = [];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    fetchData();
    fetchGraph();
    fetchAddress();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  fetchGraph() async {
    authentication.fetchGraphData(widget.uid).then((res) {
      print("GRAPH");
      print(res);

      for (var i = 0; i < res['y-axes'].length; i++) {
        y.add(double.parse(res['y-axes'][i]));
        x.add((res['x-axes'][i]).toString());
      }
      setState(() {
        x = x;
        y = y;
      });
      print("Y ${y}");
    });
  }

  fetchAddress() {
    authentication.fetchAddressData().then((res) {
      print(res);
//      setState(()=>isLoading = true);
      setState(() {
        address = res;
      });
    }).catchError((e) {});
  }

  fetchData() async {
    setState(() => inProgress = true);

    authentication.fetchHomeData(widget.uid).then((res) {
      print("HOME");
      print(res);
      if (res == null) {
        setState(() {
          homeData = null;
        });
      }else{
        var data = HomeData.fromJSON(res);

        setState(() {
          homeData = data;
        });
      }

      setState(() => inProgress = false);
    });
  }

  logout() async {
    await shared.clear();
    Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => Login()),
        ModalRoute.withName("/"));
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text("HOME"),
        centerTitle: false,
        actions: <Widget>[
          InkWell(
            onTap: logout,
            child: Padding(
              padding: EdgeInsets.only(right: 10.0),
              child: Icon(Icons.power_settings_new),
            ),
          )
        ],
      ),
      backgroundColor: Colors.black,
      body: inProgress
          ? Loader()
          : homeData != null
              ? HomeView(
                  homeData: homeData,
                  x: x,
                  y: y,
                  address: address,
                )
              : Container(
                  child: Center(
                    child: Text("No data found",style: TextStyle(color: Colors.white),),
                  )
                ),
    );
  }
}

class HomeView extends StatelessWidget {
  HomeData homeData;
  String address;
  List<String> x = [];
  List<double> y = [];

  HomeView({this.homeData, this.x, this.y, this.address});

  List<TableRow> widgets = [];

  @override
  Widget build(BuildContext context) {
    double flexVal = 1.5;
    if (MediaQuery.of(context).orientation == Orientation.portrait &&
        MediaQuery.of(context).size.width <= 320) {
      flexVal = 1.0;
    }

    widgets = [];
    widgets.add(
      TableRow(
        children: [
          rowDesign('Date', true),
          rowDesign('Post', true),
          rowDesign('Amount', true),
          rowDesign('Account', true)
        ],
      ),
    );

    // TODO: implement build
    return ListView(
      addAutomaticKeepAlives: true,
      shrinkWrap: true,
      children: <Widget>[
        Container(
          height: 35.0,
          child: Image.asset("images/bettinglogo.png"),
        ),
        SizedBox(
          height: 10.0,
        ),
        Padding(
          child: SectionView(
            homeData: homeData,
          ),
          padding: EdgeInsets.symmetric(horizontal: 10.0),
        ),
        SizedBox(
          height: 10.0,
        ),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 20.0),
          height: 250,
          color: Colors.black54,
          child: CustomGraph(
            x: x,
            y: y,
          ),
        ),
        Container(
          alignment: Alignment.center,
          child: Text(
            (homeData != null) ? homeData?.title : '',
            style: TextStyle(color: Colors.white),
          ),
        ),
        SizedBox(
          height: 5.0,
        ),
        Container(
          decoration: BoxDecoration(
              border: Border.all(color: Colors.black, width: 1.0)),
          height: MediaQuery.of(context).orientation == Orientation.landscape
              ? 200
              : 300,
          child: Column(
            children: <Widget>[
              Table(
                columnWidths: {
                  0: FlexColumnWidth(0.8),
                  1: FlexColumnWidth(flexVal), // - is ok
                  2: FlexColumnWidth(0.6), //- ok as well
                  3: FlexColumnWidth(1),
                },
                children: widgets,
              ),
              Expanded(
                child: ListView(
                  children: <Widget>[TableView(homeData: homeData)],
                ),
              )
            ],
          ),
        ),
        Container(
          height: 30.0,
          color: bgColor,
        ),
        BattingPage(),
        Address(address: address)
      ],
    );
  }

  /*
* ,
* */
  Widget rowDesign(String name, bool flag) {
    return Container(
      decoration: BoxDecoration(
        color: flag ? bgColor : Colors.transparent,
      ),
      alignment: Alignment.center,
      padding: EdgeInsets.only(top: 10.0, bottom: 10.0, right: 1.0, left: 1),
      child: Text(
        (name == null) ? '-' : name,
        style: TextStyle(
            color: flag ? Colors.white : Colors.white, fontSize: 11.0),
      ),
    );
  }
}

class SectionView extends StatelessWidget {
  HomeData homeData;

  SectionView({this.homeData});

  TextStyle homeTextStyle = TextStyle(
    color: Colors.white,
    fontSize: 15.0,
  );
  double height = 4.0;

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      color: Colors.black87,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Column(
            children: <Widget>[
              Text(
                homeData?.allTimeProfile.label,
                style: homeTextStyle,
              ),
              SizedBox(
                height: height,
              ),
              Text(
                convert(homeData?.allTimeProfile.value),
                style: homeTextStyle,
              ),
            ],
          ),
          Column(
            children: <Widget>[
              Text(
                homeData?.yearToDate.label,
                style: homeTextStyle,
              ),
              SizedBox(
                height: height,
              ),
              Text(
                convert(homeData?.allTimeProfile.value),
                style: homeTextStyle,
              ),
            ],
          ),
          Column(
            children: <Widget>[
              Text(
                homeData.lastPeriod.label,
                style: homeTextStyle,
              ),
              SizedBox(
                height: height,
              ),
              Text(
                convert(homeData?.lastPeriod.value),
                style: homeTextStyle,
              ),
            ],
          ),
        ],
      ),
    );
  }

  convert(double value) {
    return "€ $value";
//    return FlutterMoneyFormatter(
//        amount: value,
//        settings: MoneyFormatterSettings(
//            symbol: '€'
//        )
//    ).output.compactSymbolOnLeft;
  }
}

class TableView extends StatelessWidget {
  HomeData homeData;

  TableView({this.homeData});

  List<TableRow> widgets = [];

  @override
  Widget build(BuildContext context) {
    print(MediaQuery.of(context).orientation);
    double flexVal = 1.5;
    if (MediaQuery.of(context).orientation == Orientation.portrait &&
        MediaQuery.of(context).size.width <= 320) {
      flexVal = 1.0;
    }
    homeData.tableData.map(
      (TableData data) {
        widgets.add(
          TableRow(
            children: [
              rowDesign(data.date, false, false, context, Alignment.center),
              rowDesign(data.text, false, false, context, Alignment.centerLeft),
              rowDesign(data.amount.toString(), false, false, context,
                  Alignment.centerRight),
              rowPdfDesign(data.account.toString(), false, true, context,
                  data.pdf, Alignment.centerRight)
            ],
          ),
        );
      },
    ).toList();

    // TODO: implement build
    return Table(
      columnWidths: {
        0: FlexColumnWidth(0.8),
        1: FlexColumnWidth(flexVal), // - is ok
        2: FlexColumnWidth(0.6), //- ok as well
        3: FlexColumnWidth(1),
      },
      defaultVerticalAlignment: TableCellVerticalAlignment.middle,
      children: widgets,
    );
  }

  openPDF(link, BuildContext context) {
    if (link != '') {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => PDFview(
                link: link,
              ),
        ),
      );
    }
  }

/*
* ,
* */
  Widget rowDesign(String name, bool flag, bool isPdf, BuildContext context,
      Alignment alignment) {
//    print("PDF $name" );
    return Container(
      decoration: BoxDecoration(
        color: flag ? Colors.grey : Colors.transparent,
      ),
      alignment: alignment,
      padding: EdgeInsets.only(top: 10.0, bottom: 10.0, right: 1.0, left: 1),
      child: isPdf
          ? name != ''
              ? GestureDetector(
                  onTap: () {
                    openPDF(name, context);
                  },
                  child: Image.asset(
                    "images/pd.png",
                    height: 22.0,
                  ))
              : Container()
          : Text(
              (name == null) ? '-' : name,
              style: TextStyle(
                  color: flag ? Colors.white : Colors.white, fontSize: 11.0),
            ),
    );
  }

  Widget rowPdfDesign(String name, bool flag, bool isPdf, BuildContext context,
      String url, Alignment alignment) {
//    print("PDF $name" );
    return Container(
      decoration: BoxDecoration(
        color: flag ? Colors.grey : Colors.transparent,
      ),
      alignment: alignment,
      padding: EdgeInsets.only(top: 10.0, bottom: 10.0, right: 1.0, left: 1),
      child: GestureDetector(
        onTap: () {
          openPDF(url, context);
        },
        child: SafeArea(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.end,
            children: <Widget>[
              Text(
                (name == null) ? '-' : name,
                style: TextStyle(
                    color: flag ? Colors.white : Colors.white, fontSize: 12.0),
              ),
              url != ''
                  ? Image.asset(
                      "images/pd.png",
                      height: 20.0,
                      width: 20.0,
                    )
                  : Container(
                      width: 20.0,
                    )
            ],
          ),
        ),
      ),
    );
  }
}
